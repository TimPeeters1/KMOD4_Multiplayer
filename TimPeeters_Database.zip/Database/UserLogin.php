<?php

include 'DatabaseConnector.php';
include 'DatabaseFunctions.php';
        
        GetSession();
        session_start();
        
        if (!GetServerID()) {
            echo "0";
            return;
        }

        $Username = htmlspecialchars(GetURLVariable("Username", 0, 35, ""));
        $Password = htmlspecialchars(GetURLVariable("Password", 0, 35, ""));

        $LoginResult = $mysqli->query("SELECT ID, Username FROM Users WHERE Username ='" . $Username . "' AND Password ='". $Password . "'");

        $row = $LoginResult->fetch_assoc();


        if($row["Username"] == $Username){
           echo json_encode($row);

        }
        else{
            echo("0");
        }



?>
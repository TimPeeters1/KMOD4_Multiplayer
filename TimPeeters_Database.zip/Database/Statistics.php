<?php

include 'DatabaseConnector.php';
include 'DatabaseFunctions.php';


    //query for list of top 5 scores of last month.
    $queryTop = "SELECT UserID, AVG(Score), Date as avg_score FROM Scores WHERE Date > date_sub(now(), interval 1 month) GROUP BY Score ORDER BY AVG(Score) DESC LIMIT 5";
              
    if (!($result = $mysqli->query($queryTop))) {
        showerror($mysqli->errno,$mysqli->error);
    }   
       
    while ($row = $result->fetch_assoc()){
            echo json_encode($row);
        
            //Enable <br> for readability. Breaks Unity json.
            echo "<br>";
    }
    
    //get amount of plays last month.
    $queryPlays = "SELECT COUNT(*) FROM (SELECT Date FROM Scores WHERE Date > date_sub(now(), interval 1 month)) AS subquery";
        
    if (!($result2 = $mysqli->query($queryPlays))) {
        echo '0';
    }  
    
    echo ('{"monthlyplays:' . json_encode($result2->fetch_assoc()) . '}');
?>
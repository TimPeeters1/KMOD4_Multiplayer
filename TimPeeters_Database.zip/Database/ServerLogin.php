<?php

include 'DatabaseConnector.php';
include 'DatabaseFunctions.php';

        $Session_ID = 0;
        $ID = htmlspecialchars(GetURLVariable("ID", -1, -1, ""));
        $Password = htmlspecialchars(GetURLVariable("Password", -1, -1, ""));
        
        $PasswordResult = $mysqli->query("SELECT ID FROM Server WHERE ID ='" . $ID . "' AND Password ='". $Password . "'");

        $row = $PasswordResult->fetch_assoc();

    
        if($row["ID"] == $ID){
            session_start();
            $_SESSION["Server_ID"] = $ID;
            echo(session_id());
        }
        else{
            echo("0");
        }

?>
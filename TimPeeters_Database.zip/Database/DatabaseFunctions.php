<?php

//Thanks to Nathan for this one.
function GetURLVariable($urlVar, $minNumber, $maxNumber, $defaultVal = 0) {
    
    $result = $defaultVal;
    
    if ( isset($_GET[$urlVar]) || !empty($_GET[$urlVar]))
    {
        $result = $_GET[$urlVar];
    }
    
    if ($result > $maxNumber && $maxNumber != -1) 
    {
        $offresultset = $maxNumber;
    }
    
    if ($result < 0 && $minNumber != -1)
    {
        $result = $minNumber;
    }

    return $result;
}

function GetSession() {
    if ($_GET['Session_ID']) 
    { 
        $ID=htmlspecialchars($_GET['Session_ID']);
        session_id($ID);
    }
    else{
        echo '0';
        return;
    }
}

function GetServerID() {
    if (isset($_SESSION["Server_ID"]) && $_SESSION["Server_ID"]!=0) 
    {
        return true;
    } 
    else 
    {
        return false;
    }
}


?>
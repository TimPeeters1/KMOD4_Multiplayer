<?php

include 'DatabaseConnector.php';
include 'DatabaseFunctions.php';

    GetSession();
    session_start();
        
    if (!GetServerID()) {
        echo "0";
        return;
    }
        
    $Score =  GetURLVariable("Score", -1, -1, "");
    $UserID = GetURLVariable("UserID", -1, -1, "");
    //$GameID = GetURLVariable("GameID", -1, -1, "");
        
    $query = "INSERT INTO Scores(Score, UserID, Date) VALUES (" . $Score . "," . $UserID . ",CURRENT_TIMESTAMP)";
    
    //echo($query);

    if (!($result = $mysqli->query($query)))
        echo '0';
    else
    {
        $mysqli->query($query);
    }
                 
?>